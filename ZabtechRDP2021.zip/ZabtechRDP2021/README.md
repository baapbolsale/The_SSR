# RDP SERVER WINDOWS2020 GRATIS
## _Gratis Selama 6 Jam, Mudah, and Workid!_

[![NGROK](https://ngrok.com/static/img/ngrok-black.svg)](https://nodesource.com/products/nsolid)

[![forthebadge](http://forthebadge.com/images/badges/built-with-love.svg)](http://forthebadge.com)

Remote Desktop Protocol is a network protocol used by Microsoft Windows Terminal Services and Remote Desktop.

- RDP ini aktif selama 6 jam
- Bisa untuk keperluan pribadi atau tugas sekolah baik kantor dan lainya.
- ✨ Gratis Tentunya ✨

## Fitur

- [x] Bot Usage
- [x] Drag and drop all file (drop semua file apapun dari Laptop/PC/Komputer)
- [x] Import and save files from GitHub, Dropbox, Google Drive and One Drive
- [x] Reuploader
- [x] SG Server

## S & K

- Dilarang menggunakan RDP ini untuk melihat porno.
- Jangan mengganti nama user pembuatnya.
- Jangan shutdwon RDP karena servernya bakalan ikut mati.
- CPU jangan sampek 100 nanti RDP otomatis mati dan harus buat lagi.


## Penginstalan


+ Klik Fork untuk membuat RDP (Untuk Android/Phone Pilih Mode Desktop).
+ Masuk https://dashboard.ngrok.com to get NGROK_AUTH_TOKEN
+ Pilih Settings > Secrets > New repository secret
+ Untuk Nama Secret: Enter NGROK_AUTH_TOKEN
+ Buat: Visit https://dashboard.ngrok.com/auth/your-authtoken Copy dan tempel di colum
+ Pilih Add Secret
+ Pilih  > CI > Run workflow
+ Refresh Github untuk melihat > build
+ Tekan Menu "RDP INFO LOGIN" untuk mengetahui IP, User, Password.

